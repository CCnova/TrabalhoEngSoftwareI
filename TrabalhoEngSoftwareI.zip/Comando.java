package br.ufba.trabalho.biblioteca;

public interface Comando {
	public void executar(int codigo1, int codigo2);

	public void executar(int codigo1);
}
