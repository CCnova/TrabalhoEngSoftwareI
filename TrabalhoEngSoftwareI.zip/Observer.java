package br.ufba.trabalho.biblioteca;

public interface Observer {
	public Object update(Livro livro);
}

