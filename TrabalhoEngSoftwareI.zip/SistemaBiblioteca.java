package br.ufba.trabalho.biblioteca;

import java.io.IOException;
public class SistemaBiblioteca {
	
	public static void main(String[] args) throws IOException {
		InterfaceUsuario interfaceUsuario = new InterfaceUsuario();
		
		interfaceUsuario.fazerLoopEntrada();
	}

}
